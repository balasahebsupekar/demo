package com.hsbc.raven;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.support.converter.SimpleMessageConverter;

public class SendMsgThread implements Runnable{
	String _message;
	String _queue;
	String _exchange;
	AmqpTemplate _template;
	
	public SendMsgThread(String message, String exchange, String queue, AmqpTemplate template){
		_message = message;
		_queue = queue;
		_exchange = exchange;
		_template = template;
	}
	
	public void run() {
		for(int i =0; i< 10000;i++){
			String sendMsg =this._message;
			

			MessageProperties properties= new MessageProperties();
			properties.setContentType(MessageProperties.CONTENT_TYPE_JSON);
			Message amqpMessage = new SimpleMessageConverter().toMessage(sendMsg, properties);
			this._template.convertAndSend(this._exchange,this._queue, amqpMessage);
		}
		
	}
	public String getCurrentLocalDateTimeStamp(){
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
	}

}
