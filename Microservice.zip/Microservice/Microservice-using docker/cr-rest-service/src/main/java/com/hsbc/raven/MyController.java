package com.hsbc.raven;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Exchange;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.amqp.core.*;

@RestController
public class MyController {
	
	@RequestMapping("/sendCustomRequest")
	public String sendCustomRequest(
			@RequestParam(value="queue",defaultValue= RabbitConfiguration.direct_webapp_q) String queueName, 
			@RequestParam(value="exchange",defaultValue= RabbitConfiguration.direct_webapp_e) String exchangename, 
			@RequestParam(value="messgage",defaultValue= "test") String message, HttpServletRequest request){
		
		AmqpAdmin admin = App.rabbitContext.getBean(AmqpAdmin.class);
		String sendMsg = getCurrentLocalDateTimeStamp() +"|"+message;
		String route = queueName;
		Queue queue = new Queue(route,true);
		Exchange exchange = new TopicExchange(exchangename);
		admin.declareQueue(queue);
		admin.declareExchange(exchange);
		Binding binding = BindingBuilder.bind(queue).to(exchange).with(route).noargs();
		admin.declareBinding(binding);
		
		MessageProperties properties= new MessageProperties();
		properties.setContentType(MessageProperties.CONTENT_TYPE_JSON);
		Message amqpMessage = new SimpleMessageConverter().toMessage(sendMsg, properties);

		
		AmqpTemplate template = App.rabbitContext.getBean(AmqpTemplate.class);
		template.convertAndSend(queueName,queueName, amqpMessage);
		return "done";
	}
	
	
	
	
	@RequestMapping("/sendMessage2Queue")
	public String sendMessage2Queue(
			@RequestParam(value="queue",defaultValue= RabbitConfiguration.direct_webapp_q) String queueName, 
			@RequestParam(value="exchange",defaultValue= RabbitConfiguration.direct_webapp_e) String exchangename, 
			@RequestParam(value="messgage",defaultValue= "test") String message, HttpServletRequest request){
		
		AmqpTemplate template = App.rabbitContext.getBean(AmqpTemplate.class);
		String sendMsg = getCurrentLocalDateTimeStamp() +"|"+message;
		
		MessageProperties properties= new MessageProperties();
		properties.setContentType(MessageProperties.CONTENT_TYPE_JSON);
		Message amqpMessage = new SimpleMessageConverter().toMessage(sendMsg, properties);

		template.convertAndSend(exchangename,queueName, amqpMessage);
		return "done";
	}

	
	@RequestMapping("/send1GBMessage")
	public String send100MBMessage(
			@RequestParam(value="queue",defaultValue= RabbitConfiguration.direct_webapp_q) String queueName, 
			@RequestParam(value="exchange",defaultValue= RabbitConfiguration.direct_webapp_e) String exchangename, 
			@RequestParam(value="messgage",defaultValue= "test") String message, HttpServletRequest request){
		
		char[] chars = new char[1024 * 1024 * 500 / 2 ];
		
		Arrays.fill(chars, 'a');
		String  _100MBString = new String(chars);
		
		AmqpTemplate template = App.rabbitContext.getBean(AmqpTemplate.class);
		String sendMsg = getCurrentLocalDateTimeStamp() +"|"+message + _100MBString;
		
		MessageProperties properties= new MessageProperties();
		properties.setContentType(MessageProperties.CONTENT_TYPE_JSON);
		Message amqpMessage = new SimpleMessageConverter().toMessage(sendMsg, properties);

		template.convertAndSend(exchangename,queueName, amqpMessage);
		return "done";
	}
	
	@RequestMapping("/sendMessage2Exchange")
	public String sendMessage2Exchange(
			@RequestParam(value="exchange",defaultValue= RabbitConfiguration.direct_webapp_e) String exchangename, 
			@RequestParam(value="messgage",defaultValue= "test") String message, HttpServletRequest request){
		
		AmqpTemplate template = App.rabbitContext.getBean(AmqpTemplate.class);
		String sendMsg = getCurrentLocalDateTimeStamp() +"|"+message ;
		
		MessageProperties properties= new MessageProperties();
		properties.setContentType(MessageProperties.CONTENT_TYPE_JSON);
		Message amqpMessage = new SimpleMessageConverter().toMessage(sendMsg, properties);

		template.convertAndSend(exchangename, amqpMessage);
		return "done";
	}
	
	@RequestMapping("/sendMilMessage")
	public String sendMilMessage(
			@RequestParam(value="queue",defaultValue= RabbitConfiguration.direct_webapp_q) final String queueName, 
			@RequestParam(value="exchange",defaultValue= RabbitConfiguration.direct_webapp_e) final String exchangename, 
			@RequestParam(value="messgage",defaultValue= "test") final String message,final  HttpServletRequest request){
		
		char[] chars = new char[1024 * 1 / 2 ];
		
		Arrays.fill(chars, 'a');
		String  _1KString = new String(chars);
		
		AmqpTemplate template = App.rabbitContext.getBean(AmqpTemplate.class);
		
		for(int i =0; i<10;i++){
			Runnable r = new SendMsgThread(_1KString, exchangename, queueName, template);
			new Thread(r).start();
		}
		return "done";
		
	}
	
	@RequestMapping("/sendMilMessage512KB")
	public String sendMilMessage512KB(
			@RequestParam(value="queue",defaultValue= RabbitConfiguration.direct_webapp_q) final String queueName, 
			@RequestParam(value="exchange",defaultValue= RabbitConfiguration.direct_webapp_e) final String exchangename, 
			@RequestParam(value="messgage",defaultValue= "test") final String message,final  HttpServletRequest request){
		
		char[] chars = new char[1024 * 512 / 2 ];
		
		Arrays.fill(chars, 'a');
		String  _512KString = new String(chars);
		
		AmqpTemplate template = App.rabbitContext.getBean(AmqpTemplate.class);
		
		for(int i =0; i<10;i++){
			Runnable r = new SendMsgThread(_512KString, exchangename, queueName, template);
			new Thread(r).start();
		}
		return "done";
		
	}
	
	
	
	public String getCurrentLocalDateTimeStamp(){
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
	}
	
	@RequestMapping("/showMQdepth")
	public String showMQdepth(@RequestParam(value="queue",defaultValue="myQueue") String message, HttpServletRequest request){
		AmqpAdmin admin = App.rabbitContext.getBean(AmqpAdmin.class);
		return 	admin.getQueueProperties(message).toString();
	}
	
	@RequestMapping("/showMaxHeap")
	public String showMaxHeap(){
		long hSize=Runtime.getRuntime().totalMemory() / 1024 / 1024;
		long hmaxSize=Runtime.getRuntime().maxMemory()  /1024 / 1024;
		long hfreeSize=Runtime.getRuntime().freeMemory() /1024 / 1024;
		return "<html> heapsize : "+ String.valueOf(hSize) +""
				+ "MB </br> hmaxSize : "+ String.valueOf(hmaxSize) +""
						+ "MB </br> hfreeSize : "+ String.valueOf(hfreeSize) +"MB </br></html>";				
	}
	

	
	@RequestMapping("/hello")
	
	public String hello(){
		System.out.println("got request");
		return 	"hello1";
	}
	
	@RequestMapping("/test")
	public String home5( HttpServletRequest request){

		
		return "hello";
	}
}
