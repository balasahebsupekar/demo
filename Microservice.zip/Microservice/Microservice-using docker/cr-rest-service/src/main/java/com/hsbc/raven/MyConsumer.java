package com.hsbc.raven;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.ChannelAwareMessageListener;
import org.springframework.amqp.support.converter.SimpleMessageConverter;

import com.rabbitmq.client.Channel;

public class MyConsumer  implements ChannelAwareMessageListener{
	 public void onMessage(Message message, Channel channel) throws Exception {  
	        MessageProperties messageProperties = message.getMessageProperties();  
	        String messageContent = (String) new SimpleMessageConverter().fromMessage(message);  
	          
	         channel.basicAck(messageProperties.getDeliveryTag(), false);  
	          
	          
	        System.out.println("SimpleMessageListnerContainer: ="+messageContent);
	      
	  

	        channel.basicNack(messageProperties.getDeliveryTag(), false,false);
	  
	      
	    }  
}
