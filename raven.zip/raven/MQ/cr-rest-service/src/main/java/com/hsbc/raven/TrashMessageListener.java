package com.hsbc.raven;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.annotation.RabbitListenerConfigurer;
import org.springframework.amqp.rabbit.listener.RabbitListenerEndpointRegistrar;
import org.springframework.amqp.support.converter.SimpleMessageConverter;
import org.springframework.stereotype.Service;

@Service
public class TrashMessageListener implements RabbitListenerConfigurer{

	
	@RabbitListener(queues = RabbitConfiguration.direct_webapp_q)
	public void receiveMessage(final Message message){
		byte[] messagecontentByte= message.getBody();
		String messageContent = (String) new SimpleMessageConverter().fromMessage(message);
		System.out.println("TrashMessageListener : "+ messageContent);
		
	}
	
	
	
	@Override
	public void configureRabbitListeners(
			RabbitListenerEndpointRegistrar registrar) {
		// TODO Auto-generated method stub
		
	}

}
