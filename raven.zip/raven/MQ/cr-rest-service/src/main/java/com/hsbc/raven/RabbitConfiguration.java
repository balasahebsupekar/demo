package com.hsbc.raven;

import org.apache.tomcat.util.bcel.classfile.ConstantInteger;
import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.ChannelAwareMessageListener;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class RabbitConfiguration {
	
	public static final String direct_webapp_q="webapp.rabbit.queue";
	public static final String direct_invoice_q="invoice.rabbit.queue";
	public static final String direct_webapp_e="direct_webapp";
	public static final String fanout_e="fanout_all";

    @Bean
    public ConnectionFactory connectionFactory() {
    	CachingConnectionFactory connectionFactory =  new CachingConnectionFactory("104.197.119.14");
    	connectionFactory.setUsername("bala");
    	connectionFactory.setPassword("bala");
    	connectionFactory.setVirtualHost("/");
    	connectionFactory.setPort(5672);
    	connectionFactory.setConnectionLimit(20);
    	return connectionFactory;
    }

    @Bean
    public AmqpAdmin amqpAdmin() {
        return new RabbitAdmin(connectionFactory());
    }

    /*
    @Bean
    public RabbitTemplate rabbitTemplate() {
        return new RabbitTemplate(connectionFactory());
    }*/
    
    @Bean
    public AmqpTemplate amqpTemplate(){
    	return new RabbitTemplate(connectionFactory());
    }
    
    
    
    
    

    public static String getDirectWebappQ() {
		return direct_webapp_q;
	}

	public static String getDirectInvoiceQ() {
		return direct_invoice_q;
	}

	public static String getDirectWebappE() {
		return direct_webapp_e;
	}

	public static String getFanoutE() {
		return fanout_e;
	}

	@Bean
    public Queue myQueue() {
    	Queue queue = new Queue("myQueue");
       return queue;
    }
    
    
    
    @Bean
    public ChannelAwareMessageListener consumer(){
    	return new MyConsumer();
    }
    
}
