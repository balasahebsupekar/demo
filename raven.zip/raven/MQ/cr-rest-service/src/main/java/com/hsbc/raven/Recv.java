package com.hsbc.raven;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeoutException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.core.AmqpTemplate;

import org.springframework.amqp.rabbit.core.RabbitTemplate;

public class Recv {
	private final static String QUEUE_NAME = "webapp.rabbit.queue";

	public static void main(String[] argv) throws java.io.IOException,
			java.lang.InterruptedException, TimeoutException,
			KeyManagementException, NoSuchAlgorithmException,
			URISyntaxException {

		ConnectionFactory factory = new ConnectionFactory();
		// factory.setUri("amqp://user:HHZOx8J8xRHL@104.197.119.14:15672/kavya");
		// factory.setUri("amqp://kavya:kavya123@104.197.119.14:15672/kavya");
		/*factory.setHost("localhost");
		factory.setUsername("bala");
		factory.setPassword("bala");
		factory.setVirtualHost("/");
		factory.setPort(5672);*/
		factory.setHost("104.197.119.14");
		factory.setUsername("bala");
		factory.setPassword("bala");
		factory.setVirtualHost("/");
		factory.setPort(5672);
		// factory.setHandshakeTimeout(123233);

		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();
		System.out.println("==");
		channel.queueDeclare(QUEUE_NAME, true, false, false, null);
		

		AmqpTemplate amqTemp = new RabbitTemplate();

		System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
	}
}

/*
 * public static void main(String[] argv) throws java.io.IOException,
 * java.lang.InterruptedException, TimeoutException, KeyManagementException,
 * NoSuchAlgorithmException, URISyntaxException {
 * 
 * ConnectionFactory factory = new ConnectionFactory(); //
 * factory.setUri("amqp://user:HHZOx8J8xRHL@104.197.119.14:15672/kavya");
 * //factory.setUri("amqp://kavya:kavya123@104.197.119.14:15672/kavya");
 * factory.setHost("104.197.119.14"); factory.setUsername("bala");
 * factory.setPassword("bala"); factory.setVirtualHost("/");
 * factory.setPort(15672); //factory.setHandshakeTimeout(123233);
 * 
 * Connection connection = factory.newConnection(); Channel channel =
 * connection.createChannel();
 * 
 * channel.queueDeclare(QUEUE_NAME, false, false, false, null);
 * System.out.println(" [*] Waiting for messages. To exit press CTRL+C"); }
 */