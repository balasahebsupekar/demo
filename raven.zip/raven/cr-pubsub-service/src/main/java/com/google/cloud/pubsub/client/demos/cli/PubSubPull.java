package com.google.cloud.pubsub.client.demos.cli;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.api.services.pubsub.Pubsub;
import com.google.api.services.pubsub.model.AcknowledgeRequest;
import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.api.services.pubsub.model.PullRequest;
import com.google.api.services.pubsub.model.PullResponse;
import com.google.api.services.pubsub.model.ReceivedMessage;

public class PubSubPull {
	
	 public List<String> pull(String subStr ) throws Exception {
		 List<String> msgList= new ArrayList<String>();
	        Pubsub client = PubsubUtils.getClient();
	        String args[]={"credit-risk-176312", "pull_messages", subStr};
	        //projects/credit-risk-176312/subscriptions/cr-risk-sub
	        String subscriptionName = PubsubUtils.getFullyQualifiedResourceName(PubsubUtils.ResourceType.SUBSCRIPTION, args[0], args[2]);
	        PullRequest pullRequest = new PullRequest().setReturnImmediately(true).setMaxMessages(Main.BATCH_SIZE);

	        PullResponse pullResponse;
	        pullResponse = client.projects().subscriptions().pull(subscriptionName, pullRequest).execute();
	        List<String> ackIds = new ArrayList<>(Main.BATCH_SIZE);
	            List<ReceivedMessage> receivedMessages = pullResponse.getReceivedMessages();
	            if (receivedMessages != null) {
	                for (ReceivedMessage receivedMessage : receivedMessages) {
	                    PubsubMessage pubsubMessage =
	                            receivedMessage.getMessage();
	                    if (pubsubMessage != null  && pubsubMessage.decodeData() != null) {
	                             msgList.add(new String(pubsubMessage.decodeData(), "UTF-8"));
	                    }
	                    ackIds.add(receivedMessage.getAckId());
	                }
	                AcknowledgeRequest ackRequest = new AcknowledgeRequest();
	                ackRequest.setAckIds(ackIds);
	                client.projects().subscriptions().acknowledge(subscriptionName, ackRequest).execute();
	                
	            }
	        return msgList;   
	 }

	
	 
	static int  pull() throws Exception{
		int count=0;
    	
    	long start = System.nanoTime();
		
		//for(int i=0; i<10;i++){
			List<String> msgListFromTopic11=new PubSubPull().pull("cr-risk-sub12");
		/*	//List<String> msgListFromTopic12=new PubSubPull().pull("cr-risk-sub12");
			List<String> msgListFromTopic13=new PubSubPull().pull("cr-risk-sub13");
			List<String> msgListFromTopic14=new PubSubPull().pull("cr-risk-sub14");
			List<String> msgListFromTopic15=new PubSubPull().pull("cr-risk-sub15");
			List<String> msgListFromTopic16=new PubSubPull().pull("cr-risk-sub16");
			List<String> msgListFromTopic17=new PubSubPull().pull("cr-risk-sub17");
			List<String> msgListFromTopic18=new PubSubPull().pull("cr-risk-sub18");
			List<String> msgListFromTopic19=new PubSubPull().pull("cr-risk-sub19");
			List<String> msgListFromTopic20=new PubSubPull().pull("cr-risk-sub20");
			count = (count + msgListFromTopic11.size() + msgListFromTopic12.size() +msgListFromTopic13.size()+msgListFromTopic14.size()+msgListFromTopic15.size()+msgListFromTopic16.size()+
					msgListFromTopic17.size() +msgListFromTopic18.size()+msgListFromTopic19.size()+ msgListFromTopic20.size());
		*/
			count =count + msgListFromTopic11.size();
	//	}
		
		long time = System.nanoTime() - start;
		double timeInSeconds = time/1e9;

        System.out.println("PubSubController: read Elapsed time in seconds: " + timeInSeconds);
        System.out.println("PubSubController: read Elapsed time in count: " + count);
        
        return count;
	}
	 
	
	
	public static void main(String ar[]) throws Exception{
	 int count =PubSubPull.pull();
	 
	 System.out.println(count);
		
	}
	 
	 
/*	 public List<String> pull() throws Exception {
		 List<String> msgList= new ArrayList<String>();
	        Pubsub client = PubsubUtils.getClient();
	        String args[]={"credit-risk-176312", "pull_messages", "cr-risk-sub"};

	        String subscriptionName = PubsubUtils.getFullyQualifiedResourceName(PubsubUtils.ResourceType.SUBSCRIPTION, args[0], args[2]);
	        PullRequest pullRequest = new PullRequest().setReturnImmediately(false).setMaxMessages(Main.BATCH_SIZE);

	        do {
	            PullResponse pullResponse;
	            pullResponse = client.projects().subscriptions()
	                    .pull(subscriptionName, pullRequest)
	                    .execute();
	            List<String> ackIds = new ArrayList<>(Main.BATCH_SIZE);
	            List<ReceivedMessage> receivedMessages =
	                    pullResponse.getReceivedMessages();
	            if (receivedMessages != null) {
	                for (ReceivedMessage receivedMessage : receivedMessages) {
	                    PubsubMessage pubsubMessage =
	                            receivedMessage.getMessage();
	                    if (pubsubMessage != null
	                            && pubsubMessage.decodeData() != null) {
	                       // System.out.println(
	                         //       new String(pubsubMessage.decodeData(),
	                           //             "UTF-8"));
	                        msgList.add(new String(pubsubMessage.decodeData(), "UTF-8"));
	                    }
	                    ackIds.add(receivedMessage.getAckId());
	                }
	                AcknowledgeRequest ackRequest = new AcknowledgeRequest();
	                ackRequest.setAckIds(ackIds);
	                client.projects().subscriptions()
	                        .acknowledge(subscriptionName, ackRequest)
	                        .execute();
	            }
	        } while (System.getProperty(Main.LOOP_ENV_NAME) != null);
	        return msgList;   
	 }*/

	 
}
