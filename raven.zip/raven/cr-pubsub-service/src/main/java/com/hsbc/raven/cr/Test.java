package com.hsbc.raven.cr;

import java.util.ArrayList;
import java.util.List;

import com.google.cloud.pubsub.client.demos.cli.PubSubPublish;
import com.google.cloud.pubsub.client.demos.cli.PubSubPull;

public class Test {

	public static void main(String ar[]) throws Exception{
		List<String> msgForPush=new ArrayList<String>();
		msgForPush.add("one");
		msgForPush.add("two");
		
		new PubSubPublish().push(msgForPush);
		
		List<String> msgListFromTopic=new PubSubPull().pull();
		System.out.println(msgListFromTopic);
		
	}
}
