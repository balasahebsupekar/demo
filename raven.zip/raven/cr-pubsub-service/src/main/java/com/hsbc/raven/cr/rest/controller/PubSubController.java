package com.hsbc.raven.cr.rest.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.cloud.pubsub.client.demos.cli.PubSubPublish;
import com.google.cloud.pubsub.client.demos.cli.PubSubPull;

@RestController
public class PubSubController {
	
	private static final Logger LOGGER = Logger.getLogger(PubSubController.class);

    @RequestMapping("/read")
    public Integer read(@RequestParam(value="msg") String msg)  throws Exception {
    	int count=0;
    	
    	long start = System.nanoTime();
		
    	
    
    	List<String> msgListFromTopic11=new PubSubPull().pull(msg);
		
    	long time = System.nanoTime() - start;
		double timeInSeconds = time/1e9;

        System.out.println("PubSubController: read Elapsed time in seconds: " + timeInSeconds);
        System.out.println("PubSubController: read Elapsed time in count: " + msgListFromTopic11.size());
        
        return count=msgListFromTopic11.size();
    	
        
		
    }  
    
    
    
    
    @RequestMapping(value="/publish", method = RequestMethod.POST)
    public String publish(@RequestParam(value="msg") String msg, @RequestBody List<String> reqMsgList) throws Exception {
    
    	PubSubPublish.pushMsg("cr-risk-topic");
	

    	return "done!!!";
    }
    
    @RequestMapping("/publish_get")
    public Integer publish_get()  throws Exception {
    	

    	PubSubPublish.pushMsg("cr-risk-topic");
	
        
		return 0;
    }  
    
   
    	
}