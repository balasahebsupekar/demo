package com.google.cloud.pubsub.client.demos.cli;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.api.services.pubsub.Pubsub;
import com.google.api.services.pubsub.model.AcknowledgeRequest;
import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.api.services.pubsub.model.PullRequest;
import com.google.api.services.pubsub.model.PullResponse;
import com.google.api.services.pubsub.model.ReceivedMessage;

public class PubSubPull {
	
	 public static void main(String ar[])
	            throws IOException {
	        Pubsub client = PubsubUtils.getClient();
	        String args[]={"credit-risk-176312", "pull_messages", "cr-risk-sub"};

	     //   Main.checkArgsLength(args, 3);
	        String subscriptionName = PubsubUtils.getFullyQualifiedResourceName(PubsubUtils.ResourceType.SUBSCRIPTION, args[0], args[2]);
	        PullRequest pullRequest = new PullRequest().setReturnImmediately(false).setMaxMessages(Main.BATCH_SIZE);

	        do {
	            PullResponse pullResponse;
	            pullResponse = client.projects().subscriptions()
	                    .pull(subscriptionName, pullRequest)
	                    .execute();
	            List<String> ackIds = new ArrayList<>(Main.BATCH_SIZE);
	            List<ReceivedMessage> receivedMessages =
	                    pullResponse.getReceivedMessages();
	            if (receivedMessages != null) {
	                for (ReceivedMessage receivedMessage : receivedMessages) {
	                    PubsubMessage pubsubMessage =
	                            receivedMessage.getMessage();
	                    if (pubsubMessage != null
	                            && pubsubMessage.decodeData() != null) {
	                        System.out.println(
	                                new String(pubsubMessage.decodeData(),
	                                        "UTF-8"));
	                    }
	                    ackIds.add(receivedMessage.getAckId());
	                }
	                AcknowledgeRequest ackRequest = new AcknowledgeRequest();
	                ackRequest.setAckIds(ackIds);
	                client.projects().subscriptions()
	                        .acknowledge(subscriptionName, ackRequest)
	                        .execute();
	            }
	        } while (System.getProperty(Main.LOOP_ENV_NAME) != null);
	    }


}
