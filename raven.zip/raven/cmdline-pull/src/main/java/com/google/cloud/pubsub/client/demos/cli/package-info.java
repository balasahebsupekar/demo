/**
 * A package for Cloud Pub/Sub sample command line application.
 */

/**
 * @author Takashi Matsuo <tmatsuo@google.com>
 */

package com.google.cloud.pubsub.client.demos.cli;
