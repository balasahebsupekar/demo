package com.google.cloud.pubsub.client.demos.cli;
// Imports the Google Cloud client library

import com.google.cloud.pubsub.v1.Publisher;

import com.google.pubsub.v1.TopicName;

import com.google.protobuf.ByteString;
import com.google.pubsub.v1.PubsubMessage;

import java.io.IOException;



public class PubSubPublish {
	//TopicName topic = TopicName.create("credit-risk-176312", "cr-risk-topic1");

  public static void main(String ar[]) throws IOException{
    Publisher publisher=null;// =  new PubSubPublish().publisher;
    try {
      String topicId ="cr-risk-topic";// System.getenv("PUBSUB_TOPIC");
      TopicName topicName = TopicName.create("credit-risk-176312", topicId);
      // create a publisher on the topic
      if (publisher == null) {
    	  publisher = Publisher.defaultBuilder(topicName).build();
      }
      // construct a pubsub message from the payload
      final String payload = "first message";//req.getParameter("payload");
      PubsubMessage pubsubMessage =
          PubsubMessage.newBuilder().setData(ByteString.copyFromUtf8(payload)).build();

      publisher.publish(pubsubMessage);
      publisher.shutdown();
      // redirect to home page
      //resp.sendRedirect("/");
    } catch (Exception e) {
      //resp.sendError(HttpStatus.SC_INTERNAL_SERVER_ERROR, e.getMessage());
    	e.printStackTrace();
    }finally{
    	
       

    }
  }
// [END pubsub_appengine_flex_publish]

  private Publisher publisher;

  public PubSubPublish() { }

  PubSubPublish(Publisher publisher) {
    this.publisher = publisher;
  }
  
  
}