package com.hsbc.raven.cr;

import org.apache.log4j.Logger;


public class Test {
	private static final Logger LOGGER = Logger.getLogger(Test.class);
	 public static void main(String args[]) {
		 LOGGER.info("start ==============");
		 LOGGER.error("End==============");
	    }

}
